{\rtf1\ansi\ansicpg1252\cocoartf2821
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tqr\tx720\tqr\tx1440\tqr\tx2160\tqr\tx2880\tqr\tx3600\tqr\tx4320\tqr\tx5040\tqr\tx5760\tqr\tx6480\tqr\tx7200\tqr\tx7920\tqr\tx8640\partightenfactor0

\f0\fs24 \cf0 # Prebro Coin (PBC) - ERC-20 Token\
\
This repository contains the Solidity smart contract for **Prebro Coin (PBC)**, an ERC-20 token backed by gold reserves.\
\
## Features\
- 1 PBC = 1 gram of gold.\
- Whitelisting for trial phase.\
- Pausable transfers.\
- Transparent gold reserve tracking.\
\
## Contract Details\
- **Token Name**: Prebro Coin\
- **Token Symbol**: PBC\
- **Decimals**: 18\
- **Website**: [www.prebro.com](https://www.prebro.com)\
- **Email**: info@prebro.com\
\
## Deployment\
- Deploy the contract using Hardhat or Remix.\
- Initial gold reserve must be provided during deployment.\
\
## License\
MIT License}